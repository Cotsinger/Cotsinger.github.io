Limpid Jekyll Theme

Clone the repo to get started

Included :

 * Facebook/Twitter/LinkedIn/G+ Share
 * Disqus Integration
 * Prettify JS Code highlighter
 * Font Awesome
 * Author block and profile
 * Download source facility
 * Feature image on posts

# Desktop Preview

![alt text](https://raw.githubusercontent.com/pranavrajs/limpid/master/images/ss-1.png "Desktop Preview 1")
![alt text](https://raw.githubusercontent.com/pranavrajs/limpid/master/images/ss-2.png "Desktop Preview 2")
![alt text](https://raw.githubusercontent.com/pranavrajs/limpid/master/images/ss-3.png "Desktop Preview 3")


# Mobile Preview

![alt text](https://raw.githubusercontent.com/pranavrajs/limpid/master/images/ss-mobile.png "Mobile Preview 1")

If you are using this theme. Please update the wiki with your url.
